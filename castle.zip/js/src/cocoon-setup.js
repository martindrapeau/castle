Cocoon.Utils.setAntialias(false);
Cocoon.Utils.setNPOTEnabled(true);