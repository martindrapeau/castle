(function() {
	window._levels || (window._levels = []);
	var sprites = [];
	window._levels.push({"tileWidth":64,"tileHeight":64,"width":90,"height":20,"backgroundImage":"#background-town","puzzle":false,"level":3,"name":"Wharehouse","x":0,"y":-580,"viewportTop":0,"viewportRight":0,"viewportLeft":0,"backgroundColor":"rgba(2, 10, 23, 1)","sprites":sprites,"state":"pause","viewportBottom":0,"time":0});
}).call(this);